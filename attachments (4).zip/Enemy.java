public class Enemy extends Unit{
  
  private boolean isBoss;
  
  public Enemy(String n, int h, int str, int intl, int def, int spd, boolean bos){
    super(n, h, str, intl, def, spd);
    isBoss=bos;
  }
  
  public boolean getisBoss(){
    return isBoss;
  }
  
  public String viewStats(){
    return "ENEMY:\n" + super.viewStats();
  }
}