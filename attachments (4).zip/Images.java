public class Images extends JFrame{
  
  private ImageIcon image1;
  private JLabel label1;
  
  public Images(){
    setLayout(new FlowLayout());

    image1 =  new ImageIcon(getClass.getResource("use.jpg"));
      
    label1 = new JLabel1(image1);
    add(label1);
  }
}