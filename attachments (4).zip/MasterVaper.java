public class MasterVaper extends Character{
  
  public MasterVaper(String n){
    super(n,10,2,4,2,4);
  }
  
  public String viewProfile(){
    return "Student type: MasterVaper\n" + super.viewProfile();
  }
}