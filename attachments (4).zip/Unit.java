abstract class Unit{
  
  private String name;
  private int maxhp;
  private int hp;
  private int strength;
  private int intelligence;
  private int defense;
  private int speed;
  
  public Unit(String n, int h, int str, int intl, int def, int spd){
    name=n;
    if(h>0){
      maxhp=h;
      hp=h;
    }
    else{
      maxhp=10;
      hp=10;
    }
    if(str>0)
      strength=str;
    else
      strength=3;
    if(intl>0)
      intelligence=intl;
    else
      intelligence=3;
    if(def>0)
      defense=def;
    else
      defense=3;
    if(spd>0)
      speed=spd;
    else
      speed=3;
  }
  
  public Unit(){
    this("Unit", 10, 3, 3, 3, 3);
  }
  
  public String getName(){
    return name;
  }
  
  public int getmaxHP(){
    return maxhp;
  }
  
  public int getHP(){
    return hp;
  }
  
  public int getStrength(){
    return strength;
  }
  
  public int getDefense(){
    return defense;
  }
  
  public int getIntelligence(){
    return intelligence;
  }
  
  public int getSpeed(){
    return speed;
  }
  
  public void takedamage(int d){
    hp=hp-d;
    if(hp<=0){
      hp=0;
    }
  }
  
  public void restoreHP(int r){
    if(r>maxhp-hp)
      hp=maxhp;
    else
      hp+=r;
  }
  
  public void fullHeal(){
    hp=maxhp;
  }

  public void statincrease(int input){
    if(input<0)
      maxhp+=2;
    else if(input==0)
      strength+=1;
    else if(input==1)
      intelligence+=1;
    else if(input==2)
      defense+=1;
    else
      speed+=1;
  }
  
  public String viewStats(){
    return "Name: " + name + "\nHp: "+hp+"/"+maxhp+"\nStrength: "+ strength + "\nIntelligence: " + intelligence+ "\nDefense: " + defense+"\nSpeed: " + speed;
  }
  
}