import java.util.Scanner;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.*;

public class Main{
  
  public static void main(String[] args){
    
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(1000, 500);
    frame.setVisible(true);
  
    JLabel test = new JLabel("Welcome to the Game!");
    
    JPanel pan = new JPanel();
    pan.add(test);
    frame.add(test);
   
    Scanner scan = new Scanner(System.in);
    boolean gamerunning = true;
    int c=1;
    int d=2;
    int e=1;
    System.out.println("Welcome to Student Survival, a game by Eric Gu. You are a high school student who entered a dream where you must survive as long as you can from an onslaught of enemies. First, choose a name.");
    String s = scan.nextLine();
    int n=-1;
    int asdf=0;
    System.out.println("Hello " + s);
    while(n<0||n>3){
      if(asdf>0)
        System.out.println("Invalid input. Please try again.");
      System.out.println("Now please choose the type of student you wish to play.\nType 0 for BigBoiJock, 1 for MasterVaper, 2 for NoLifeNerd, or 3 for TeachersPet.");
      n=scan.nextInt();
      asdf++;
    }   
    Character player;
    if(n==0)
      player = new BigBoiJock(s);
    else if(n==1)
      player = new MasterVaper(s);
    else if(n==2)
      player = new NoLifeNerd(s);
    else if(n==3)
      player = new TeachersPet(s);   
    else
      player = new BigBoiJock(s);
    System.out.println("Here's a freebie item for good luck.");
    player.gainitem(new Healingitem());
    System.out.println("Hello " + s +".\nYou are ready to begin. Here is your an overview of your chracter's profile.\n");
    System.out.println(player.viewProfile()+"\n"+player.viewItems());
    System.out.println("The game will now begin");
    Combat game = new Combat();
    while(gamerunning){
      if(c%5==0){
        game.playercombat(player, new Enemy("Random Boss", e+6,1+e+(int)(d*Math.random()),1+e+(int)(d*Math.random()),1+e+(int)(d*Math.random()),1+e+(int)(d*Math.random()),true));
      }
      else{
        game.playercombat(player, new Enemy("Random Guy", e+3,e+(int)(d*Math.random()),e+(int)(d*Math.random()),e+(int)(d*Math.random()),e+(int)(d*Math.random()),false));
      } 
      if(game.getWin()==false){
        gamerunning=false;
      }
      else{
        c++;
        if(c%5==0)
          e++;
        System.out.println("Congrats you're moving on.");
        test.setText("Status:\n" + player.viewStats()+"\n"+player.viewItems()+ "Enemies defeated: " + (c-1));
      }
    }
    test.setText("Game Over");
    System.out.println("Game over, you we're able to get past " + (c-1) + " enemies. Hope you had fun");
  }
  
}