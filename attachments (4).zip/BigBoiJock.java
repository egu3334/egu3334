public class BigBoiJock extends Character{
  
  public BigBoiJock(String n){
    super(n,10,5,1,4,2);
  }
  
  public String viewProfile(){
    return "Student type: BigBoiJock\n" + super.viewProfile();
  }
}