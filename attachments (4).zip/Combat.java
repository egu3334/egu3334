import java.util.Scanner;

public class Combat{
  
  boolean yourturn;
  boolean inbattle;
  boolean win=true;
  boolean ranaway;
  int turncount;
  int playerdecision;
  int enemydecision;
  Scanner scan=new Scanner(System.in);
  
  public void playercombat(Character c, Enemy e){
    System.out.println("You entered a battle with " + e.getName());
    inbattle=true;
    ranaway=false;
    if(c.getSpeed()>e.getSpeed()){
      System.out.println("You are faster. You go first.");
      yourturn=true;
    }
    else{
      System.out.println("You are slower. You go second.");
      yourturn=false;
    }
    while(inbattle){
      if(yourturn){
        System.out.println(e.viewStats()+"\n"+c.viewStats()+"\n"+c.viewItems());
        playerdecision=-1;
        while(playerdecision<0||playerdecision>2){
          System.out.println("It's your turn. What will you do?\nInput 0 to attack, 1 to use an item, or 2 to try and run if your opponent is not a boss.");
          playerdecision=scan.nextInt();
        }
        playerturn(playerdecision,c,e);
      }
      else{
        System.out.println("The enemy's turn!");
        if(e.getHP()<e.getmaxHP()/4 && e.getisBoss())
          enemyturn(1,c,e);
        else
          enemyturn(2,c,e);
      }
      checkplayerstatuses(c,e);
      yourturn = !yourturn;
    }
    battleresolution(c,e);
  }
  
  public void checkplayerstatuses(Character c, Enemy e){
    if(ranaway)
      inbattle=false;
    else if(c.getHP()>0&&e.getHP()>0)
      inbattle=true;
    else if(c.getHP()<=0){
      win = false;
      inbattle=false;
    }
    else{
      win=true;
      inbattle=false;
    }
  }
  
  public void playerturn(int i, Character c, Enemy e){
    int d;
    if(i==0){
      d=c.getStrength()-e.getDefense();
      if(d<=0)
        d=1;
      e.takedamage(d);
      System.out.println("The enemy took " + d+" damage!"); 
    }
    else if(i==1){
      if(c.getInventorySize()==0)
        System.out.println("You have no items. You did nothing!");
      else{
        d=-1;
        System.out.println(c.viewItems());
        while(d<0||d>=c.getInventorySize()){
          System.out.println("Choose which item to use based on its array index. (1st item is at 0, 2nd at 1, etc.)");
          d=scan.nextInt();
        }
        c.consumeitem(d);
      }
    }
    else{
      if(c.getSpeed()>e.getSpeed()){
        System.out.println("You are faster. You ran.");
        ranaway=true;
      }
      else if(e.getisBoss()){
        System.out.println("You can't run from the boss and failed.");
        ranaway=false;
      }
      else{
        System.out.println("You are slower. You failed to run.");
        ranaway=false;
      }
    }
  }
  
  public void enemyturn(int i, Character c, Enemy e){
    double d;
    boolean usedpower=false;
    if(usedpower==true || i==2){
      d=Math.random();
      if(d<(double)e.getIntelligence()/(double)c.getIntelligence())
        System.out.println("The enemy attacked but was dumb and missed)");
      else{
        d=e.getStrength()-c.getDefense();
        if(d<=0)
          d=1;
        e.takedamage((int)d);
        System.out.println("The enemy took " + d+" damage!"); 
      }
    }
    else{
      System.out.println("The boss powered up. It restored it health and increased its stats!");
      e.restoreHP(e.getmaxHP()/3);
      for(int j=0; j<4; j++)
        e.statincrease(j);
      usedpower=true;
    }
  }
  
  public boolean battleresolution(Character c, Enemy e){
    int x=30;
    if(ranaway){
      System.out.println("You ranaway.");
      c.gainxp(1);
      return true;
    }
    else if(win){
      System.out.println("You won");
      if(e.getisBoss()){
        c.gainitem(new StatBooster());
        c.gainitem(new Healingitem());
        x=60;
      }
      c.gainxp(x);
      return true;
    }
    else{
      return false;
    }
  }
  
  public boolean getWin(){
    return win;
  }
  
  
}