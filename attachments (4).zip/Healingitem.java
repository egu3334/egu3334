public class Healingitem extends Item{
  
  private int numberhealed;
  
  public Healingitem(String n, int h, int heal){
    super(n,h);
    this.changeDescription("Heals " + heal + " hp.");
    numberhealed=heal;
  }
  
  public Healingitem(){
    this("Potion",1,5);
  }
  
  public int getNumberHealed(){
    return numberhealed;
  }
  
  public String className(){
    return "Healing Item";
  }
}