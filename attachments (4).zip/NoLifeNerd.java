public class NoLifeNerd extends Character{
  
  public NoLifeNerd(String n){
    super(n,10,2,5,1,4);
  }
  
  public String viewProfile(){
    return "Student type: NoLifeNerd\n" + super.viewProfile();
  }
}