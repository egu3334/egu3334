abstract class Item{
  
  private String name;
  private int amount;
  private String description;
  
  public Item(String n, int h){
    name=n;
    if(h>0)
      amount=h;
    else
      amount=1;
    description="";
  }
  
  public Item(){
    this("empty",1);
  }
  
  public int getAmount(){
    return amount;
  }
  
  public String getName(){
    return name;
  }
  
  public String getDescription(){
    return description;
  }
  
  public void changeDescription(String s){
    description=s;
  }
  
  public void increaseamount(){
    amount++;
  }
  
  public void decreaseamount(){
    amount--;
  }
  
  abstract String className();
  
  public String toString(){
    return "Name: " + name + "\nAmount: " + amount+"\nDescription: " + description;
  }
}