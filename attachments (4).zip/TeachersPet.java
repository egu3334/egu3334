public class TeachersPet extends Character{
  
  public TeachersPet(String n){
    super(n,10,2,3,5,2);
  }
  
  public String viewProfile(){
    return "Student type: TeachersPet\n" + super.viewProfile();
  }
}