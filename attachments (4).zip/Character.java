import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

abstract class Character extends Unit{
  
  private int level;
  private int xp;
  private List<Item> inventory;
  
  Scanner scan = new Scanner(System.in);
  
  public Character(String n, int h, int str, int intl, int def, int spd){
    super(n, h, str, intl, def, spd);
    level=1;
    xp=0;
    inventory = new ArrayList<Item>();
  }
  
  public Character(){
    this("Player", 10, 3, 3, 3, 3);
  }  
  
  public int getInventorySize(){
    return inventory.size();
  }
  
  public void gainxp(int x){
    xp+=x;
    System.out.println("You gained " +x+ " xp.");
    if(xp>=100){
      xp-=100;
      this.levelup();
    }
  }
  
  public void levelup(){
    this.statincrease(-1);
    this.fullHeal();
    System.out.println("Max hp increased by 2. Hp fully restored.");
    for(int i=0; i<4;i++)
      this.statincrease(i);
    System.out.println("Strength, intelligence, defense, and speed increased by 1.");
    this.statincrease();
  }
  
  public void statincrease(){
    int input=-1;
    while(input<0||input>3){
      System.out.println("Choose a stat to increase. Input 0 for strength, 1 for intelligence, 2 for defense, and 3 for speed.");
      input=scan.nextInt();
    }
    this.statincrease(input);
  }
  
  public void gainitem(Item found){
    boolean hasitem = false;
    for(Item i: inventory){
      if(i.getName().equals(found.getName())){
        hasitem=true;
        i.increaseamount();
      }
    }
    if(!hasitem){
      inventory.add(found);
    }
    System.out.println("You gained " + found.getName() + ".");
  }
  
  public void consumeitem(int i){
    Item copy = inventory.get(i);
    if(copy.className().equals("Healing Item")){
      Healingitem temp = (Healingitem)inventory.get(i);
      this.restoreHP(temp.getNumberHealed());
    }
    else{
      StatBooster temp = (StatBooster)inventory.get(i);
      for(int j=0;j<temp.getAmountUp();j++)
        this.statincrease();
    }
    System.out.println("You used " + copy.getName());
    copy.decreaseamount();
    if(copy.getAmount()<1)
      inventory.remove(i);
  }
  
  public String viewProfile(){
    return this.viewStats()+"\nLevel: " + level + "\nExperience: " + xp;
  }
  
  public String viewItems(){
    String ret="Items:\n";
    for(Item i: inventory){
      ret=ret+i.toString()+"\n";
    }
    return ret;
  }
}
  