public class StatBooster extends Item{
  
  private int amountup;
  
  public StatBooster(String n, int h, int a){
    super(n,h);
    this.changeDescription("Gain " + amountup + " stat point(s).");
    amountup = a;
  }
  
  public StatBooster(){
    this("Basic Stat Booster",1,1);
  }
  
  public int getAmountUp(){
    return amountup;
  }
  
  public String className(){
    return "Stat Booster";
  }
  
}